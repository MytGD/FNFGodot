# A Friday Night Funkin Engine made in Godot

<p align = "center">
  <img src= "assets/images/fnf_godot_e.png" width = "300px">
</p>
